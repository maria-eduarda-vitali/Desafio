import styles from './ProjectForm.module.css';
function ProjectForm(){
    return(
        <form className={styles.form}>
            <div>
                <input type="text" name="nome" placeholder="Insira o seu nome" />
            </div>

            <div>
                <input type="text" name="endereco" placeholder="Insira seu endereço" />
            </div>

            <div>
                <input type="tel" name="tel" placeholder="Insira seu telefone"/>
            </div>
            <div>
                <input type="email" name="email" placeholder="Insira seu e-mail" />
            </div>

            <div>
                <input type="button" value="Criar" onClick="Criar"/>
            </div>
        </form>

    )
}

export default ProjectForm