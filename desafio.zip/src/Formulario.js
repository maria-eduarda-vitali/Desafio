import styles from './Formulario.module.css'
import ProjectForm from './ProjectForm'
function Formulario(){
    return (
        <div className={styles.formulario_container}>
            <h1>Adicionar registros</h1>
            <p>Adicione algum registro</p>
            <ProjectForm />
      
        </div>
    )

}

export default Formulario