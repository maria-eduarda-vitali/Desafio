import './App.css';
import Formulario from './Formulario.js';
function App() {
  return (
    <div>
       <Formulario />

    </div>
  );
}

export default App;
